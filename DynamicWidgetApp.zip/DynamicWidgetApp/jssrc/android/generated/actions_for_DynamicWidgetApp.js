//actions.js file 
function p2kwiet341880914363_bttnContinue_onClick_seq0(eventobject) {
    frmOption.show();
}

function p2kwiet341880914369_bttnLp_onClick_seq0(eventobject) {
    return createDynamicForm.call(this);
}

function p2kwiet341880914369_bttnRp_onClick_seq0(eventobject) {
    return createDynamicFormRemotely.call(this);
}

function p2kwiet341880914369_frmOption_preshow_seq0(eventobject, neworientation) {
    tmp = 0;
}