function addWidgetsfrmOption() {
    var bttnLp = new kony.ui.Button({
        "focusSkin": "sknBtnKonyThemeFocus",
        "id": "bttnLp",
        "isVisible": true,
        "onClick": p2kwiet341880914369_bttnLp_onClick_seq0,
        "skin": "sknBtnKonyThemeNormal",
        "text": "widgets(locally packaged)"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [5, 10, 5, 2],
        "marginInPixel": false,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var bttnRp = new kony.ui.Button({
        "focusSkin": "sknBtnKonyThemeFocus",
        "id": "bttnRp",
        "isVisible": true,
        "onClick": p2kwiet341880914369_bttnRp_onClick_seq0,
        "skin": "sknBtnKonyThemeNormal",
        "text": "widgets(remotely packaged)"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [5, 2, 5, 0],
        "marginInPixel": false,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    frmOption.add(bttnLp, bttnRp);
};

function frmOptionGlobals() {
    frmOption = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmOption,
        "enabledForIdleTimeout": false,
        "id": "frmOption",
        "needAppMenu": true,
        "preShow": p2kwiet341880914369_frmOption_preshow_seq0,
        "skin": "sknFrmKonyThemeNormal",
        "title": "Options"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "formAnimation": 0
        },
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "outTransitionConfig": {
            "formAnimation": 0
        },
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "sknTitleKonyTheme",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};