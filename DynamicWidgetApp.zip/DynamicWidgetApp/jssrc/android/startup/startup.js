//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "dynamicwidget",
    appName: "DynamicWidgets",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.12.36",
    serverPort: "8080",
    secureServerPort: null,
    isDebug: true,
    middlewareContext: "dynamicwidget",
    isturlbase: "http://kh2183.kitspl.com:8282/services",
    isMFApp: true,
    appKey: "aac3e80a10649f14663dd35762bbacf8",
    appSecret: "cd67f7a98a2eb55ffc5505ef46be8b04",
    serviceUrl: "http://kh2183.kitspl.com:8282/authService/100000002/appconfig",
    svcDoc: {
        "appId": "fa63cfb5-b728-45db-a1df-39195a0eb644",
        "baseId": "53f9282e-24ea-4776-8e98-fdf4246916e2",
        "name": "DynamicWidgetApp",
        "selflink": "http://kh2183.kitspl.com:8282/authService/100000002/appconfig",
        "integsvc": {
            "DynamicWidgetAppService0": "http://kh2183.kitspl.com:8282/services/DynamicWidgetAppService0"
        },
        "reportingsvc": {
            "custom": "http://kh2183.kitspl.com:8282/services/CMS",
            "session": "http://kh2183.kitspl.com:8282/services/IST"
        },
        "services_meta": {
            "DynamicWidgetAppService0": {
                "version": "1.0",
                "url": "http://kh2183.kitspl.com:8282/services/DynamicWidgetAppService0",
                "type": "integsvc"
            }
        }
    },
    eventTypes: [],
    url: "http://kh2183.kitspl.com:8282/admin/dynamicwidget/MWServlet",
    secureurl: "http://kh2183.kitspl.com:8282/admin/dynamicwidget/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    initializeUserWidgets();
    initializefooter();
    setAppHeadersAndFooters();
    frmIntroGlobals();
    frmOptionGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: true
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        init: appInit,
        showstartupform: function() {
            frmIntro.show();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("KonyTheme", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;