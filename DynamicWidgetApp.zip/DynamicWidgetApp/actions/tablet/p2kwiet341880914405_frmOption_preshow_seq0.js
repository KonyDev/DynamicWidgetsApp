function p2kwiet341880914405_frmOption_preshow_seq0(eventobject, neworientation) {
    tmp = 0;
}