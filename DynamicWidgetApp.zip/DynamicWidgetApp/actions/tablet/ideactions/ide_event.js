
function p2kwiet341880914399_bttnContinue_onClick_seq0(eventobject){

frmOption.show();
	
};


function p2kwiet341880914405_frmOption_preshow_seq0(eventobject,    neworientation){

tmp=0;

};


function p2kwiet341880914405_bttnLp_onClick_seq0(eventobject){

createDynamicForm.call(this);

};


function p2kwiet341880914405_bttnRp_onClick_seq0(eventobject){

createDynamicFormRemotely.call(this);

};

